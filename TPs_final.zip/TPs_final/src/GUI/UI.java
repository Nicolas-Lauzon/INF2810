package GUI;

import javax.swing.*;
import java.awt.event.*;

public class UI {
    public JPanel mainPanel;
    private JButton passerLaCommandeButton;


    /*public JList getRechercheListe(){
        return getRechercheListe();
    }*/

    public UI() {

        passerLaCommandeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"hello");

            }
        });


    }

    public static void main(String[] args){
        JFrame frame = new JFrame("TP2");
        frame.setContentPane(new UI().mainPanel);
        //frame.setContentPane(new UI().panneauBouttons);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
