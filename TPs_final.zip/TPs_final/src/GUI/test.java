package GUI;
import java.awt.*;


import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

import Inventory.Inventory;
import Inventory.Node;
import Inventory.Tree;
import Inventory.Objet;


public class test extends JFrame {
    private JPanel mainPanel;
    private JButton ajouterAuPanierButton;
    private JButton viderLePanierButton;
    private JButton retirerDuPanierButton;
    private JButton passerLaCommandeButton;
    private JTextField rechercheFieldNom;

    private JPanel panneauBoutton;
    private JPanel panneauFields;
    private JLabel etiquetteRechercherParNom;
    private JTextField rechercheFieldCode;
    private JTextField rechercheFieldType;
    private JLabel etiquetteRechercheParCode;
    private JLabel etiquetteRechercheParType;
    private JPanel counterField;
    private JPanel testAllo;
    private JButton commande;
    private JScrollPane fenetreRecherche;
    private JScrollPane fenetreInventaire;
    private JScrollPane fenetrePanier;
    private JScrollPane counterRecherche;
    private JScrollPane counterInventaire;
    private JScrollPane counterPanier;

    private ArrayList<Objet> listeRechercheObjet;
    private ArrayList<Objet> listeInventaireObjet;
    private ArrayList<Objet> listePanierObjet;


    private JList<String> listeRechercheString;
    private JList<String> listeInventaireString;
    private JList<String> listePanierString;
    private JList<String> listeVideString;
    private Objet selectedItem;



    public test(Inventory inventory) {


        listeRechercheObjet = inventory.filter("","",null);
        listeRechercheString = new JList<>((inventory.printInventory(listeRechercheObjet).toArray(new String[0])));
        fenetreRecherche = new JScrollPane(listeRechercheString);

        listeInventaireObjet = inventory.filter("","",null);
        listeInventaireString = new JList<>((inventory.printInventory(listeInventaireObjet).toArray(new String[0])));
        fenetreInventaire = new JScrollPane(listeInventaireString);

        listePanierObjet = new ArrayList<Objet>();
        listePanierString=new JList<>();
        fenetrePanier = new JScrollPane(listePanierString);

        counterField.setLayout(new GridLayout(1,3));

        ArrayList<String> aa = new ArrayList<String>();
        ArrayList<String> aaa = new ArrayList<String>();
        ArrayList<String> aaaa = new ArrayList<String>();

        aa.add( "counter1" );
        aaa.add( "counter2" );
        aaaa.add("counter3");

        JList<String> b = new JList<>(aa.toArray(new String[0]));
        JList<String> bb = new JList<>(aaa.toArray(new String[0]));
        JList<String> bbb = new JList<>(aaaa.toArray(new String[0]));
        //int conteur1 = ;
        JScrollPane c = new JScrollPane(b);
        JScrollPane cc = new JScrollPane(bb);
        JScrollPane ccc= new JScrollPane(bbb);




        /*for (Objet objet : listeInventaireObjet){
            inventory.getNameTree().deleteInAutomate(objet.getName() , objet);
            inventory.getCodeTree().deleteInAutomate(objet.getIdentificator(),objet);
            inventory.getTypeTree().deleteInTypeAutomate(objet.getType(),objet);
        }*/


        counterField.add(c);
        counterField.add(cc);
        counterField.add(ccc);


        panneauFields.setLayout(new GridLayout(1,3));


        panneauFields.add(fenetreRecherche);
        panneauFields.add(fenetreInventaire);
        panneauFields.add(fenetrePanier);





        passerLaCommandeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                //JOptionPane.showMessageDialog(null, listePanierString.getSelectedIndex() );
                int poids=0;
                for (Objet objet : listePanierObjet){
                    if (objet.getType().equals('A')){
                        poids+=1;
                    }
                    else if (objet.getType().equals('B')){
                        poids+=3;
                    }
                    else if (objet.getType().equals('C')){
                        poids+=6;
                    }
                }
                if (poids <= 25 ) {
                    JOptionPane.showMessageDialog(null,"La commande est passé");
                }
                else
                    JOptionPane.showMessageDialog(null,"La commande n'est pas passé: le poids excede 25 kg. Le poids de votre commande est: "+poids+" kg");


            }
        });



        rechercheFieldNom.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);

                listeRechercheObjet = new ArrayList<Objet>();

                if (!rechercheFieldType.getText().equals("")) {
                    Character paramChar = rechercheFieldType.getText().charAt(0);
                    listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), paramChar);
                }
                else{
                    listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), null);

                }
                //listeRechercherObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), rechercheFieldType.getText().charAt(0));
                listeRechercheString = new JList<>(inventory.printInventory(listeRechercheObjet).toArray(new String[0]));
                fenetreRecherche = new JScrollPane(listeRechercheString);

                listeRechercheString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {

                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeRechercheObjet.get(listeRechercheString.getSelectedIndex());
                    }
                });

                panneauFields.remove(0);
                panneauFields.add(fenetreRecherche,0);
                panneauFields.validate();
                panneauFields.repaint();

            }
        });
        rechercheFieldCode.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                listeRechercheObjet = new ArrayList<Objet>();

                if (!rechercheFieldType.getText().equals("")) {
                    Character paramChar = rechercheFieldType.getText().charAt(0);
                    listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), paramChar);
                }
                else{
                    listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), null);

                }
                //listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), rechercheFieldType.getText().charAt(0));
                listeRechercheString = new JList<>(inventory.printInventory(listeRechercheObjet).toArray(new String[0]));

                fenetreRecherche = new JScrollPane(listeRechercheString);

                listeRechercheString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {

                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeRechercheObjet.get(listeRechercheString.getSelectedIndex());
                    }
                });

                panneauFields.remove(0);
                panneauFields.add(fenetreRecherche,0);
                panneauFields.validate();
                panneauFields.repaint();

            }
        });
        rechercheFieldType.addKeyListener(new KeyAdapter() {
            @Override
            public void keyReleased(KeyEvent e) {
                super.keyReleased(e);
                listeRechercheObjet = new ArrayList<Objet>();

                if (!rechercheFieldType.getText().equals("")) {
                    Character paramChar = rechercheFieldType.getText().charAt(0);
                    listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), paramChar);
                }
                else{
                    listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), null);

                }
                //listeRechercheObjet = inventory.filter(rechercheFieldNom.getText(), rechercheFieldCode.getText(), rechercheFieldType.getText().charAt(0));
                listeRechercheString = new JList<>(inventory.printInventory(listeRechercheObjet).toArray(new String[0]));

                fenetreRecherche = new JScrollPane(listeRechercheString);

                listeRechercheString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {

                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeRechercheObjet.get(listeRechercheString.getSelectedIndex());
                    }
                });

                panneauFields.remove(0);
                panneauFields.add(fenetreRecherche,0);
                panneauFields.validate();
                panneauFields.repaint();

            }
        });
        viderLePanierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

                for (Objet objet : listePanierObjet){
                    inventory.getNameTree().insertInAutomate(objet.getName(), objet);
                    inventory.getCodeTree().insertInAutomate(objet.getIdentificator(), objet);
                    inventory.getTypeTree().insertInTypeAutomate(objet.getType(), objet);
                }
                listeRechercheObjet = inventory.filter("","",null);
                listeRechercheString = new JList<>((inventory.printInventory(listeRechercheObjet).toArray(new String[0])));
                fenetreRecherche = new JScrollPane(listeRechercheString);

                listeInventaireObjet = inventory.filter("","",null);
                listeInventaireString = new JList<>((inventory.printInventory(listeInventaireObjet).toArray(new String[0])));
                fenetreInventaire = new JScrollPane(listeInventaireString);

                panneauFields.remove(0);
                panneauFields.add(fenetreRecherche,0);
                panneauFields.remove(1);
                panneauFields.add(fenetreInventaire,1);

                listePanierObjet = new ArrayList<Objet>();
                listeVideString = new JList<>();

                listeRechercheString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {

                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeRechercheObjet.get(listeRechercheString.getSelectedIndex());
                    }
                });

                listeInventaireString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeInventaireObjet.get(listeInventaireString.getSelectedIndex());
                    }
                });

                fenetrePanier = new JScrollPane(listeVideString);
                panneauFields.remove(2);
                panneauFields.add(fenetrePanier,2);
                panneauFields.validate();
                panneauFields.repaint();
            }
        });
        retirerDuPanierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Objet temp;
                temp = listePanierObjet.get(listePanierString.getSelectedIndex());
                listePanierObjet.remove(temp);
                inventory.getNameTree().insertInAutomate(temp.getName(), temp);
                inventory.getCodeTree().insertInAutomate(temp.getIdentificator(), temp);
                inventory.getTypeTree().insertInTypeAutomate(temp.getType(), temp);

                listeRechercheObjet = inventory.filter("","",null);
                listeRechercheString = new JList<>(inventory.printInventory(listeRechercheObjet).toArray(new String[0]));
                fenetreRecherche = new JScrollPane(listeRechercheString);

                listeInventaireObjet = inventory.filter("","",null);
                listeInventaireString = new JList<>((inventory.printInventory(listeInventaireObjet).toArray(new String[0])));
                fenetreInventaire = new JScrollPane(listeInventaireString);

                panneauFields.remove(0);
                panneauFields.add(fenetreRecherche,0);
                panneauFields.remove(1);
                panneauFields.add(fenetreInventaire,1);



                listeRechercheString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {

                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeRechercheObjet.get(listeRechercheString.getSelectedIndex());
                    }
                });

                listeInventaireString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeInventaireObjet.get(listeInventaireString.getSelectedIndex());
                    }
                });

                listePanierString = new JList<>(inventory.printInventory(listePanierObjet).toArray(new String[0]));
                fenetrePanier = new JScrollPane(listePanierString);
                panneauFields.remove(2);
                panneauFields.add(fenetrePanier,2);
                panneauFields.validate();
                panneauFields.repaint();


            }
        });


        listeRechercheString.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                super.mouseClicked(e);
                //JOptionPane.showMessageDialog(null,"allo");
                selectedItem = listeRechercheObjet.get(listeRechercheString.getSelectedIndex());
            }
        });

        listeInventaireString.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                super.mouseClicked(e);
                //JOptionPane.showMessageDialog(null,"allo");
                selectedItem = listeInventaireObjet.get(listeInventaireString.getSelectedIndex());
            }
        });

        ajouterAuPanierButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                listePanierObjet.add(selectedItem);
                inventory.getNameTree().deleteInAutomate(selectedItem.getName(),selectedItem);
                inventory.getCodeTree().deleteInAutomate(selectedItem.getIdentificator(),selectedItem);
                inventory.getTypeTree().deleteInTypeAutomate(selectedItem.getType(),selectedItem);

                listeRechercheObjet = inventory.filter("","",null);
                listeRechercheString = new JList<>(inventory.printInventory(listeRechercheObjet).toArray(new String[0]));
                fenetreRecherche = new JScrollPane(listeRechercheString);

                listeInventaireObjet = inventory.filter("","",null);
                listeInventaireString = new JList<>((inventory.printInventory(listeInventaireObjet).toArray(new String[0])));
                fenetreInventaire = new JScrollPane(listeInventaireString);

                panneauFields.remove(0);
                panneauFields.add(fenetreRecherche,0);
                panneauFields.remove(1);
                panneauFields.add(fenetreInventaire,1);



                listeRechercheString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {

                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeRechercheObjet.get(listeRechercheString.getSelectedIndex());
                    }
                });

                listeInventaireString.addMouseListener(new MouseAdapter() {
                    @Override
                    public void mouseClicked(MouseEvent e) {
                        super.mouseClicked(e);
                        //JOptionPane.showMessageDialog(null,"allo");
                        selectedItem = listeInventaireObjet.get(listeInventaireString.getSelectedIndex());
                    }
                });

                listePanierString = new JList<>(inventory.printInventory(listePanierObjet).toArray(new String[0]));
                fenetrePanier = new JScrollPane(listePanierString);
                panneauFields.remove(2);
                panneauFields.add(fenetrePanier,2);
                panneauFields.validate();
                panneauFields.repaint();


            }
        });
    }


    public static void main(String[] args){
        Tree nameTree = new Tree(new Node());
        Tree codeTree = new Tree(new Node());
        Tree typeTree = new Tree(new Node());
        Inventory inventory = new Inventory(nameTree, codeTree, typeTree);

        String fileName = "./inventaire.txt";
        inventory.createInventory(fileName);


        JFrame frame = new JFrame("TP2");
        frame.setContentPane(new test(inventory).mainPanel);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);

    }


}
