package com.company;


import GUI.UI;
import Inventory.Inventory;
import Inventory.Node;
import Inventory.Tree;
import Inventory.Objet;

import javax.swing.*;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        Tree nameTree = new Tree(new Node());
        Tree codeTree = new Tree(new Node());
        Tree typeTree = new Tree(new Node());
        Inventory inventory = new Inventory(nameTree, codeTree, typeTree);

        String fileName = "./inventaire.txt";
        inventory.createInventory(fileName);

        //ArrayList<Objet> result = inventory.filter("", "", 'C');
        System.out.println("fffff");
        System.out.println(inventory.printInventory(inventory.getInventory()));
        JList<String> displayInventory = new JList<>((inventory.printInventory(inventory.getInventory()).toArray(new String[0])));
        JScrollPane scrollPane = new JScrollPane(displayInventory);
        UI ui = new UI();

        //ui.getRechercheListe().add(scrollPane);
        ui.mainPanel.setVisible(true);
        ArrayList<Objet> result = inventory.filter("ami", "", 'B');

        inventory.getNameTree().deleteInAutomate("ami", result.get(0));
        inventory.getTypeTree().deleteInTypeAutomate('B', result.get(0));

    }
}
